package com.sportradar.unifiedodds.example.examples;

import com.pushtechnology.gateway.framework.Publisher;
import com.pushtechnology.gateway.framework.StateHandler;
import com.pushtechnology.gateway.framework.StreamingSourceHandler;
import com.pushtechnology.gateway.framework.exceptions.InvalidConfigurationException;
import com.sportradar.unifiedodds.example.common.GlobalEventsListener;
import com.sportradar.unifiedodds.example.common.SdkConstants;
import com.sportradar.unifiedodds.sdk.MessageInterest;
import com.sportradar.unifiedodds.sdk.OddsFeed;
import com.sportradar.unifiedodds.sdk.cfg.Environment;
import com.sportradar.unifiedodds.sdk.cfg.OddsFeedConfiguration;
import com.sportradar.unifiedodds.sdk.exceptions.InitException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Locale;
import java.util.concurrent.CompletableFuture;

import static com.pushtechnology.gateway.framework.DiffusionGatewayFramework.newSourceServicePropertiesBuilder;

/**
 * Implementation of {@link StreamingSourceHandler} which listens to Sportradar Odds feed
 * changes and publishes contents to Diffusion server.
 *
 * @author Push Technology Limited
 */

final class SportradarStreamingSourceHandler implements StreamingSourceHandler {

    private static final Logger LOG =
            LoggerFactory.getLogger(SportradarStreamingSourceHandler.class);

    private final StateHandler stateHandler;
    private final Publisher publisher;
    private final String diffusionTopicName;
    private final String fileName;
    private final OddsFeed oddsFeed;
    private final String token;
    private final SportradarDiffusionWriter diffusionWriter;

    private boolean is_ok = true;

    SportradarStreamingSourceHandler(
            final String fileName,
            final String diffusionTopicName,
            final StateHandler stateHandler,
            final Publisher publisher,
            final String token) {

        this.diffusionTopicName = diffusionTopicName;
        this.stateHandler = stateHandler;
        this.publisher = publisher;
        this.fileName = fileName;
        this.token    = token;

        LOG.info("Running the OddsFeed SDK Basic example - Diffusion session");

        LOG.info("Building the configuration using the provided token");
        OddsFeedConfiguration configuration = OddsFeed.getOddsFeedConfigurationBuilder()
                .setAccessToken(token)
                .selectEnvironment(Environment.GlobalIntegration)
                .setSdkNodeId(SdkConstants.NODE_ID)
                .setDefaultLocale(Locale.ENGLISH)
                .build();

        LOG.info("Creating a new OddsFeed instance");
        oddsFeed = new OddsFeed(new GlobalEventsListener(), configuration);
        this.diffusionWriter = new SportradarDiffusionWriter(oddsFeed, publisher, "DiffusionSessionSetup");

        LOG.info("Building a simple session which will receive all messages");
        oddsFeed.getSessionBuilder()
                .setMessageInterest(MessageInterest.AllMessages)
                .setListener(diffusionWriter)
                .build();
    }

    private void pause() {

        LOG.info("Pausing");
/*        try {
            oddsFeed.wait();
        }
        catch(InterruptedException ex) {
            LOG.warn("Interrupted Execption: ", ex);
        }*/
    }

    /* Overrides of abstract methods */

    @Override
    public SourceServiceProperties getServiceProperties() throws InvalidConfigurationException {
        return
                newSourceServicePropertiesBuilder()
                        .updateMode(SourceServiceProperties.UpdateMode.STREAMING)
                        //.payloadConvertor("Sportradar_to_JSON")
                        .build();
    }

    @Override
    public CompletableFuture<?> pause(PauseReason reason) {
        pause();
        return CompletableFuture.completedFuture(null);
    }

    @Override
    public CompletableFuture<?> resume(ResumeReason reason) {
        is_ok = true;

        return start();
    }

    @Override
    public CompletableFuture<?> start() {

        try {
            LOG.info("Opening the feed instance");
            oddsFeed.open();
            //LOG.info("Fetching Sport Data");
            //diffusionWriter.fetchSportsData();
            //LOG.info("Fetching Market Mappings");
            //diffusionWriter.fetchMarketMappings();
            LOG.info("Successfully obtained Sport Data.");
        }
        catch(InitException ex) {
            LOG.info("Unable to connect to Odds feed - {}", ex.getMessage());
        }

        return CompletableFuture.completedFuture(null);
    }

    @Override
    public CompletableFuture<?> stop() {
        pause();

        return CompletableFuture.completedFuture(null);
    }
}
